import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        char[][] alf = new char[6][6];
        char letter = 'А'; // буква А
        for (int i = 0; i < alf.length; i++) {
            for (int j = 0; j < alf[i].length; j++) {
                alf[i][j] = letter;
                letter++;
                if (letter > 'Я') break;
                if (letter == 'Ж'){
                    if(j == alf[i].length-1){
                       i++;
                       j=0;
                    } else {
                        j++;
                    }
                    alf[i][j] = 'Ё';
                }



            }

        }
        /*alf[1][0] = "Ё"; // вводим букву Ё
        char z = 1071; // буква Я
        char e = 1045; // буква Е
        char g = 1046; //буква Ж
        for (int i = 0; i < 1; i++) {
            for (int j = 0; j < 6; j++) {
                alf[i][j] = String.valueOf(a);
                a++;
            }
        }
        for (int i = 1; i < alf.length; i++) {
            for (int j = 1; j < alf[i].length; j++) {
                alf[i][j] = String.valueOf(g);
                g++;

            }

        }*/
        System.out.println(Arrays.deepToString(alf));

    }
}
/*Создайте двумерный массив и заполните его заглавными буквами русского алфавита.
 * Буква Ё должна быть на своем месте
   * */
import java.time.LocalDate;
import java.util.Arrays;

class BubbleSort {
    static void bubbleSort(LocalDate[] arrUnsort) {
        for (int i = 0; i < arrUnsort.length - 1; i++)
            for (int j = 0; j < arrUnsort.length - i - 1; j++) {
                if (arrUnsort[j].getYear() > arrUnsort[j + 1].getYear()) {
                    LocalDate swap = arrUnsort[j];
                    arrUnsort[j] = arrUnsort[j + 1];
                    arrUnsort[j + 1] = swap;
                }
            }
    }
}

class DaysSort {
    static void daysSort(LocalDate[] arrDays) {
        for (int i = 0; i < arrDays.length - 1; i++)
            for (int j = 0; j < arrDays.length - i - 1; j++) {
                if (arrDays[j].getDayOfMonth() > arrDays[j + 1].getDayOfMonth()) {
                    LocalDate swap = arrDays[j];
                    arrDays[j] = arrDays[j + 1];
                    arrDays[j + 1] = swap;
                }
            }
    }
}

    public class Main {
        public static void main(String[] args) {
            LocalDate[] date = {LocalDate.of(1990, 10, 21), LocalDate.of(1995, 11, 28),
                    LocalDate.of(1999, 12, 26), LocalDate.of(2005, 5, 30),
                    LocalDate.of(2013, 4, 9), LocalDate.of(2001, 1, 7), LocalDate.of(2007, 9, 17),
                    LocalDate.of(2000, 3, 29)};
            System.out.println(Arrays.toString(date));
            BubbleSort.bubbleSort(date);
            System.out.println(Arrays.toString(date));
            DaysSort.daysSort(date);
            System.out.println(Arrays.toString(date));
        }
    }


/*1 Создайте массив из 8 элементов. В массиве должны храниться даты (класс LocalDate).
 Чтобы создать элемент LocalDate используйте метод LocalDate.of(год, месяц, день), где год, месяц и день - целые числа.
Выведите массив в консоль.
2 Напишите метод, который отсортирует массив дат по году. Выведите массив в консоль.
3 Напишите метод, который отсортирует массив дат по дню месяца. Выведите массив в
консоль.
Сортировку можно выполнить по любому из изученных алгоритмов.*/